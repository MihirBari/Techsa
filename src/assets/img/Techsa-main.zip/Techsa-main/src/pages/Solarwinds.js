import React from "react";
import { NavBar } from "../component/NavBar";
import { Container } from "react-bootstrap";

const solarwinds = () => {
  return (
    <>
      <NavBar />
      <Container>
      <div className="App">LoremahuHDAGui dbsyuag dnuiwjquu qdhuwh</div>
      </Container>
    </>
  );
};

export default solarwinds;
