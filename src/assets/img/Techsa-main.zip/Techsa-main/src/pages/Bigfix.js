import React from 'react'
import { NavBar } from "../component/NavBar";
import { Container } from "react-bootstrap";

const Bigfix = () => {
  return (
    <> 
    <NavBar />
    <Container>
    <div className="App">LoremahuHDAGui dbsyuag dnuiwjquu qdhuwh</div>
    </Container>
    </>
  )
}

export default Bigfix